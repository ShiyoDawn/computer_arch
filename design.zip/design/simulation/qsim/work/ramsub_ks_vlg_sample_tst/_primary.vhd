library verilog;
use verilog.vl_types.all;
entity ramsub_ks_vlg_sample_tst is
    port(
        CLK             : in     vl_logic;
        CLRN            : in     vl_logic;
        SPULSE          : in     vl_logic;
        sampler_tx      : out    vl_logic
    );
end ramsub_ks_vlg_sample_tst;
